const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// ---------- config ----------
const API = 'https://four.meme/meme-api/v1/public/token/search';
const TEMPLATES = (process.env.SNIPE_TEMPLATES || '1778027615735').split(',');
const PER_POOL = Number(process.env.SNIPE_PER_POOL || 3);   // first N per quote pool
const GLOBAL_MAX = Number(process.env.SNIPE_GLOBAL_MAX || 5);
const MAX_PAY = ethers.parseEther(process.env.SNIPER_MAX_PAY || '0.2');
const PLAN_ONLY = process.env.PLAN_ONLY === '1';
const ONLY_QUOTE = (process.env.SNIPE_QUOTE || '').toLowerCase(); // e.g. BNCB address filter (optional)

const CORE = ethers.getAddress('0xebe7b6c1089d9f72ad07f34e36d898e44e5e27f3');
const TOOLS = ethers.getAddress('0x97da82f56fef1a0b974587a48135fa9da2a4e905');
const WALLET = ethers.getAddress('0x2d8061328852b7e4196a482071026ce91edcba8b');
const TM2 = ethers.getAddress('0x5c952063c7fc8610ffdb798152d69f0b9550762b');
const BNB = ethers.getAddress('0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee');
const ZERO = ethers.ZeroAddress;

const KNOWN_QUOTES = {
  '0x55d398326f99059ff775485246999027b3197955': 'USDT',
  '0xce24439f2d9c6a2289f741120fe202248b666666': 'U',
  '0x4902c5ebc598265ed2212b559b042de8a5eeec3f': 'BNCB',
  '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c': 'WBNB',
};
const BLACKLIST = new Set([
  '0xfc4394f596ca30df0c7eac63fd48111034a7ffff',
  '0xb32d257b6a7b76deddbc80f6a308f3be24074444',
  '0x105c06af03f1935a88a2eadc867a5e45ae62ffff',
  '0x3bdf234051a86166f00a5b72c3ddd7fd1b9fffff',
]);
const RPCS = [
  'https://bsc-dataseed.binance.org',
  'https://bsc-dataseed1.bnbchain.org',
  'https://bsc.publicnode.com',
  'https://rpc.ankr.com/bsc',
];
const OUT_DIR = 'D:\\Backup\\Documents\\deepseek-harness\\default-workspace\\watch';
const LOG = path.join(OUT_DIR, 'pool-sniper.log');
const STATE = path.join(OUT_DIR, 'pool-state.json');
const CLI = 'C:\\Users\\Administrator\\baw-multi\\cli\\dist\\index.js';
const BAW_ENV = {
  ...process.env,
  HTTP_PROXY: 'http://127.0.0.1:7897',
  HTTPS_PROXY: 'http://127.0.0.1:7897',
  NO_PROXY: '127.0.0.1,localhost',
  NODE_USE_ENV_PROXY: '1',
  BINANCE_BAW_DIR: 'C:\\Users\\Administrator\\baw-multi\\a',
  BINANCE_INSTANCE_ID: 'baw-a',
};

fs.mkdirSync(OUT_DIR, { recursive: true });
const log = (m) => {
  const line = `[${new Date().toISOString()}] ${m}`;
  console.log(line);
  fs.appendFileSync(LOG, line + '\n');
};

const runBaw = (args) => new Promise((resolve) => {
  const c = spawn(process.execPath, [CLI, ...args], { env: BAW_ENV });
  let out = '', err = '';
  c.stdout.on('data', (d) => (out += d));
  c.stderr.on('data', (d) => (err += d));
  c.on('close', (code) => resolve({ code, out, err }));
});
const pj = (s) => { const i = s.indexOf('{'); if (i < 0) return null; try { return JSON.parse(s.slice(i)); } catch { return null; } };

const providers = new Map();
const providerFor = (url) => {
  if (!providers.has(url)) providers.set(url, new ethers.JsonRpcProvider(url, 56, { staticNetwork: true }));
  return providers.get(url);
};
async function rpc(fn) {
  let lastErr;
  for (const url of RPCS) {
    try { return await fn(providerFor(url)); } catch (e) { lastErr = e; }
  }
  throw lastErr;
}

const IFACE = new ethers.Interface([
  'function tokens(address) view returns (uint32 version, address creator, uint256 presetId, address token, string name, string symbol, uint256 maxSupply, uint256 saleAmount, uint256 raiseAmount, address quoteAsset, address vault, address curveModule, address tradeModule, address migrateModule, address tokenModule, address customData, uint256 createBlock, bool exists, bool paused, bool antiSniperEnabled)',
  'function symbol() view returns (string)',
  'function totalSupply() view returns (uint256)',
  'function approve(address,uint256)',
  'function buy(address token, uint256 amount, uint256 maxQuotePayAmount, uint256 options, bytes proof) payable',
  'function estimateBuy(address token, address trader, uint256 amount, uint256 options, bytes proof) returns (tuple(uint256 curveQuote, uint256 totalFee, uint256 userPays, uint256 userReceives, uint256 tokenAmount, uint256 executionPrice))',
]);
const ERR = {
  '0xd15b1d74': 'CoreErrBudgetNotExecutable',
  '0x96ea0b74': 'Not an Agentic Wallet with Agent ID',
  '0xe8c402c1': 'HoldCap reached (curve)',
  '0x687d0d11': 'HoldCap reached (trade)',
  '0x63d7653c': 'Creator presale cap',
  '0xa6708f30': 'Transfer locked before graduation',
  '0xa2dda494': 'Not whitelisted',
};

async function searchTokens() {
  const out = [], seen = new Set();
  for (const tpl of TEMPLATES) {
    try {
      const r = await fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0' },
        body: JSON.stringify({ pageIndex: 1, pageSize: 30, orderBy: 'Time', templateId: tpl }),
      });
      const j = await r.json().catch(() => null);
      for (const it of j?.data || []) {
        const a = String(it.tokenAddress || '').toLowerCase();
        if (!a || seen.has(a)) continue;
        seen.add(a);
        it.__tpl = tpl;
        out.push(it);
      }
    } catch (e) { log('[warn] search ' + tpl + ': ' + e.message); }
  }
  return out;
}

(async () => {
  let state = { seen: [], pools: {}, bought: [], failed: [], attempts: 0 };
  if (fs.existsSync(STATE)) { try { state = Object.assign(state, JSON.parse(fs.readFileSync(STATE, 'utf8'))); } catch {} }
  const save = () => fs.writeFileSync(STATE, JSON.stringify(state, null, 2));

  log(`pool sniper armed: templates=${TEMPLATES.join(',')} perPool=${PER_POOL} global=${GLOBAL_MAX} maxPay=${ethers.formatEther(MAX_PAY)} planOnly=${PLAN_ONLY} onlyQuote=${ONLY_QUOTE || 'any'}`);

  const readToken = async (token) => rpc(async (p) => {
    const supply = IFACE.decodeFunctionResult('totalSupply', await p.call({ to: token, data: IFACE.encodeFunctionData('totalSupply') }))[0];
    let sym = '';
    try { sym = IFACE.decodeFunctionResult('symbol', await p.call({ to: token, data: IFACE.encodeFunctionData('symbol') }))[0]; } catch {}
    return { supply, sym };
  });

  const poolOf = async (token) => rpc(async (p) => {
    try {
      const r = await p.call({ to: CORE, data: IFACE.encodeFunctionData('tokens', [token]) });
      const d = IFACE.decodeFunctionResult('tokens', r);
      if (!d[17]) return null; // exists
      const q = String(d[9]).toLowerCase();
      const quote = q === ZERO ? 'BBNB' : q; // native bucket key
      return { quote, symbol: q === ZERO ? 'BNB' : (KNOWN_QUOTES[q] || 'ERC20') };
    } catch { return null; }
  });

  const estimate = async (token, amount) => rpc(async (p) => {
    const r = await p.call({ from: WALLET, to: TOOLS, data: IFACE.encodeFunctionData('estimateBuy', [token, WALLET, amount, 0, '0x']) });
    const d = IFACE.decodeFunctionResult('estimateBuy', r)[0];
    return { userPays: d[2], tokenAmount: d[4] };
  });

  const eligibility = async (token, amount, maxPay) => {
    try {
      await rpc(async (p) => p.call({ from: WALLET, to: CORE, data: IFACE.encodeFunctionData('buy', [token, amount, maxPay, 0, '0x']), value: maxPay }));
      return { ok: true };
    } catch (e) {
      const raw = e?.data || e?.info?.error?.data || '';
      const sel = String(raw).slice(0, 10);
      return { ok: false, msg: ERR[sel] || sel || (e.shortMessage || e.message) };
    }
  };

  const buy = async (token, sym, quote) => {
    const { supply } = await readToken(token);
    if (!supply) { log(`[skip] ${sym} no supply`); return 'skip'; }
    const amount = (supply * 99n) / 10000n; // 0.99% of maxSupply

    let est = null;
    try { est = await estimate(token, amount); } catch (e) { log(`[warn] ${sym} estimate: ${e.shortMessage || e.message}`); }
    const cost = est?.userPays ?? 0n;
    const buyAmount = est?.tokenAmount && est.tokenAmount > 0n ? est.tokenAmount : amount;
    log(`[quote] ${sym} pool=${quote.symbol} amount=${ethers.formatUnits(amount, 18)} pay=${cost ? ethers.formatEther(cost) : '?'}`);
    if (cost && cost > MAX_PAY) { log(`[skip] ${sym} cost over cap`); return 'skip'; }

    const el = await eligibility(token, buyAmount, cost || MAX_PAY);
    if (!el.ok) { log(`[BLOCKED] ${sym} ${el.msg}`); return 'blocked'; }

    const maxPay = cost && cost > 0n ? (cost * 102n) / 100n : MAX_PAY;
    if (PLAN_ONLY) {
      log(`[PLAN] ${sym} pool=${quote.symbol} amount=${ethers.formatUnits(buyAmount, 18)} maxPay=${ethers.formatEther(maxPay)}`);
      return 'plan';
    }

    let payValue = maxPay;
    const isNative = quote.symbol === 'BNB' || quote.symbol === 'WBNB';
    if (!isNative) {
      const sw = pj((await runBaw(['market-order', 'swap', '--fromTokenQty', ethers.formatEther(maxPay), '--fromToken', BNB, '--toToken', quote.quote, '--binanceChainId', '56', '--json'])).out);
      if (!sw?.success) { log(`[fail] ${sym} swap ${sw?.error?.message || ''}`); return 'fail'; }
      await new Promise((r) => setTimeout(r, 6000));
      const st = pj((await runBaw(['market-order', 'list', '--orderId', sw.data.orderId, '--json'])).out);
      const o = st?.data?.list?.[0];
      if (o?.status !== 'FINISHED') { log(`[wait] ${sym} swap ${o?.status || ''}`); return 'fail'; }
      const have = ethers.parseEther(String(o.toTokenActualQty));
      const ap = pj((await runBaw(['contract-call', 'preview', '--binanceChainId', '56', '--from', WALLET, '--to', quote.quote,
        '--value', '0', '--inputData', IFACE.encodeFunctionData('approve', [CORE, have.toString()]), '--json'])).out);
      if (!ap?.success) { log(`[fail] ${sym} approve ${ap?.error?.message || ''}`); return 'fail'; }
      await runBaw(['contract-call', 'execute', '--requestId', ap.data.requestId, '--json']);
      await new Promise((r) => setTimeout(r, 5000));
      payValue = 0n;
    }

    const data = IFACE.encodeFunctionData('buy', [token, buyAmount, maxPay, 0, '0x']);
    const pv = pj((await runBaw(['contract-call', 'preview', '--binanceChainId', '56', '--from', WALLET, '--to', CORE,
      '--value', payValue.toString(), '--inputData', data, '--json'])).out);
    if (!pv?.success) {
      const msg = pv?.error?.message || '';
      const hit = Object.keys(ERR).find((k) => msg.toLowerCase().includes(k.slice(2)));
      log(`[BLOCKED] ${sym} ${hit ? ERR[hit] : msg}`);
      return 'blocked';
    }
    const ex = pj((await runBaw(['contract-call', 'execute', '--requestId', pv.data.requestId, '--json'])).out);
    if (!ex?.success) { log(`[FAIL] ${sym} ${ex?.error?.message || ''}`); return 'fail'; }

    log(`[BUY] ${sym} ${ex.data.status} tx=${ex.data.txHash || '-'}`);
    state.bought.push(token.toLowerCase());
    const posPath = path.join(OUT_DIR, 'positions.json');
    let positions = [];
    try { positions = JSON.parse(fs.readFileSync(posPath, 'utf8')); } catch {}
    positions.push({ token: token.toLowerCase(), symbol: sym, amount: buyAmount.toString(), costWei: (cost || maxPay).toString(), quote: quote.symbol, tx: ex.data.txHash || '', tpDone: false, ts: Date.now() });
    fs.writeFileSync(posPath, JSON.stringify(positions, null, 2));
    return 'bought';
  };

  // main loop
  setInterval(async () => {
    try {
      if (state.bought.length >= GLOBAL_MAX && !PLAN_ONLY) return;
      const items = await searchTokens();
      // sort candidates oldest-first so "first three" is deterministic
      items.sort((a, b) => Number(a.createDate) - Number(b.createDate));

      for (const it of items) {
        const addr = String(it.tokenAddress || '').toLowerCase();
        if (!addr || state.seen.includes(addr)) continue;
        if (state.bought.length >= GLOBAL_MAX && !PLAN_ONLY) break;

        const sym = it.shortName || it.name || '';
        if (BLACKLIST.has(addr) || /^test/i.test(sym)) {
          state.seen.push(addr); save();
          log(`[filter] ${sym} (blacklist or test prefix, does not consume a pool slot)`);
          continue;
        }

        const pool = await poolOf(addr);
        if (!pool) { state.seen.push(addr); save(); log(`[filter] ${sym} not an OpenFour token (no config)`); continue; }
        if (ONLY_QUOTE && pool.quote !== ONLY_QUOTE) { state.seen.push(addr); save(); log(`[filter] ${sym} quote=${pool.symbol} not target`); continue; }

        const key = '56:' + pool.quote;
        const g = state.pools[key] || { quote: pool.quote, symbol: pool.symbol, tokens: [] };
        if (g.tokens.length >= PER_POOL) { state.seen.push(addr); save(); log(`[filter] ${sym} pool ${pool.symbol} already has ${PER_POOL}`); continue; }

        // rank & persist
        g.tokens.push({ token: addr, symbol: sym, createDate: Number(it.createDate) });
        state.pools[key] = g;
        state.seen.push(addr);
        save();
        log(`[rank] ${sym} pool=${pool.symbol} slot ${g.tokens.length}/${PER_POOL} global ${state.bought.length}/${GLOBAL_MAX}`);

        const res = await buy(addr, sym, pool);
        if (res === 'bought' || res === 'plan') save();
        if (res === 'blocked' || res === 'fail') {
          state.failed.push(addr);
          save();
          log(`[slot-consumed] ${sym} failed/blocked — no backfill for this pool slot`);
        }
      }
    } catch (e) {
      log('poll error: ' + (e.message || e));
    }
  }, 1500);
})();
