const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);
const CLI = 'C:\\Users\\Administrator\\baw-multi\\cli\\dist\\index.js';

const TOKENS = [
  ['DAGOU', '0x39b58c3930d4352b2e4d8697ea6188c864455555', '0.000232903894934086'],
  ['POA', '0xd87adb2e47979d6cb323896b1a9320e0dd132213', '1'],
  ['AGENT', '0xc4605c6a7765138784b3ca6f9a88e1c249a0d21f', '2'],
  ['牛币', '0xac0d1e7a790469df1f5cd8ab95c38546a053289b', '46904.96382701293010944'],
  ['GSTOCK', '0x4a8fb3757678214aea93e5903732c65ea260caa9', '100471.744726483186214514'],
  ['GANG', '0x0c6302401aa5325c2e36f170f52c00b1d220b405', '0.000000000000161249'],
  ['DAWG', '0x846029a144d1756fed43ee0b3f54591bc964ad8b', '44415.090686003377078272'],
  ['BIBI', '0x24881534007105a6d0728040ffdda1682ff92998', '45984.80414209120141312'],
];

const env = {
  ...process.env,
  HTTP_PROXY: 'http://127.0.0.1:7897',
  HTTPS_PROXY: 'http://127.0.0.1:7897',
  NO_PROXY: '127.0.0.1,localhost',
  NODE_USE_ENV_PROXY: '1',
  BINANCE_BAW_DIR: 'C:\\Users\\Administrator\\baw-multi\\a',
  BINANCE_INSTANCE_ID: 'baw-a',
};

(async () => {
  for (const [sym, addr, amount] of TOKENS) {
    try {
      const { stdout } = await execFileAsync(process.execPath, [CLI, 'market-order', 'quote',
        '--fromTokenQty', amount, '--fromToken', addr, '--toToken', '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE',
        '--binanceChainId', '56', '--json'], { env, timeout: 45000 });
      const i = stdout.indexOf('{');
      const j = JSON.parse(stdout.slice(i));
      if (j.success) console.log(`${sym.padEnd(8)} ${amount.padEnd(24)} -> ${j.data.toCoinAmount} BNB (${j.data.toCoinSymbol})`);
      else console.log(`${sym.padEnd(8)} no route: ${j.error?.message || ''}`);
    } catch (e) {
      console.log(`${sym.padEnd(8)} quote failed`);
    }
  }
})();
