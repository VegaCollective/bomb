const fs = require('fs');
const { ethers } = require('ethers');

const W1 = '0x2d8061328852b7E4196a482071026cE91edcBa8b';
const file = 'D:\\Backup\\Documents\\deepseek-harness\\default-workspace\\watch\\tx-history.json';

(async () => {
  const j = JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
  const txs = j?.data?.transactions || [];
  const tokens = new Map(); // addr -> {symbol, decimals}

  for (const tx of txs) {
    for (const h of tx.txHashList || []) {
      const ins = h.instructions || {};
      for (const side of ['send', 'receive']) {
        for (const it of ins[side] || []) {
          const ti = it.tokenInfo;
          if (!ti?.contractAddress) continue;
          const addr = String(ti.contractAddress).toLowerCase();
          if (addr === '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee') continue;
          if (!tokens.has(addr)) tokens.set(addr, { symbol: ti.symbol || '?', decimals: Number(ti.decimals ?? 18) });
        }
      }
    }
  }

  console.log('unique tokens in history:', tokens.size);

  const p = new ethers.JsonRpcProvider('https://bsc-dataseed.binance.org', 56, { staticNetwork: true });
  const iface = new ethers.Interface([
    'function balanceOf(address) view returns (uint256)',
    'function symbol() view returns (string)',
  ]);

  const held = [];
  for (const [addr, meta] of tokens) {
    try {
      const bal = iface.decodeFunctionResult('balanceOf', await p.call({ to: addr, data: iface.encodeFunctionData('balanceOf', [W1]) }))[0];
      if (bal > 0n) {
        held.push({ addr, symbol: meta.symbol, decimals: meta.decimals, amount: ethers.formatUnits(bal, meta.decimals) });
      }
    } catch {}
  }

  console.log('\nheld but possibly hidden:', held.length);
  for (const h of held) console.log(`${h.symbol.padEnd(12)} ${h.addr}  ${h.amount}`);
})().catch(e => console.error('FATAL', e.message));
