const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// ---------- config ----------
const RPC = 'https://bsc-dataseed.binance.org';
const CORE = '0xebe7b6C1089D9F72aD07f34E36d898e44E5e27f3';
const CORES = [CORE, '0x912CEf0C3aE9Ab6eB3Ec87cab69371cFb317Ab94'];
const PRESET_ID = 1778027615735n;
const WALLET = '0x2d8061328852b7E4196a482071026cE91edcBa8b'; // W1
const MAX_BUYS = 5;
const MAX_PAY = ethers.parseEther(process.env.SNIPER_MAX_PAY || '0.2');
// known test tokens — never buy these
const BLACKLIST = [
  '0xfc4394f596ca30df0c7eac63fd48111034a7ffff',
  '0xb32d257b6a7b76deddbc80f6a308f3be24074444',
  '0x105c06af03f1935a88a2eadc867a5e45ae62ffff',
  '0x3bdf234051a86166f00a5b72c3ddd7fd1b9fffff',
];
const OUT_DIR = 'D:\\Backup\\Documents\\deepseek-harness\\default-workspace\\watch';
const LOG = path.join(OUT_DIR, 'sniper.log');
const CURSOR = path.join(OUT_DIR, 'sniper-cursor.txt');
const STATE = path.join(OUT_DIR, 'sniper-state.json');

const CLI = 'C:\\Users\\Administrator\\baw-multi\\cli\\dist\\index.js';
const BAW_ENV = {
  ...process.env,
  HTTP_PROXY: 'http://127.0.0.1:7897',
  HTTPS_PROXY: 'http://127.0.0.1:7897',
  NO_PROXY: '127.0.0.1,localhost',
  NODE_USE_ENV_PROXY: '1',
  BINANCE_BAW_DIR: 'C:\\Users\\Administrator\\baw-multi\\a',
  BINANCE_INSTANCE_ID: 'baw-a',
};

fs.mkdirSync(OUT_DIR, { recursive: true });
const log = (m) => {
  const line = `[${new Date().toISOString()}] ${m}`;
  console.log(line);
  fs.appendFileSync(LOG, line + '\n');
};

const runBaw = (args) => new Promise((resolve) => {
  const c = spawn(process.execPath, [CLI, ...args], { env: BAW_ENV });
  let out = '', err = '';
  c.stdout.on('data', (d) => (out += d));
  c.stderr.on('data', (d) => (err += d));
  c.on('close', (code) => resolve({ code, out, err }));
});
const parseJson = (s) => {
  const i = s.indexOf('{');
  if (i < 0) return null;
  try { return JSON.parse(s.slice(i)); } catch { return null; }
};

const IFACE = new ethers.Interface([
  'function tokens(address) view returns (uint256)',
  'function symbol() view returns (string)',
  'function totalSupply() view returns (uint256)',
]);
const BUY_IFACE = new ethers.Interface([
  'function buy(address token, uint256 amount, uint256 maxPay, uint256 deadline, bytes permitData) payable',
]);

(async () => {
  const p = new ethers.JsonRpcProvider(RPC, 56, { staticNetwork: true });
  let cursor = 0;
  if (fs.existsSync(CURSOR)) cursor = parseInt(fs.readFileSync(CURSOR, 'utf8'), 10) || 0;
  if (!cursor) cursor = await p.getBlockNumber();

  let state = { bought: 0, seen: [] };
  if (fs.existsSync(STATE)) {
    try { state = JSON.parse(fs.readFileSync(STATE, 'utf8')); } catch {}
  }

  log(`sniper armed: preset=${PRESET_ID} wallet=${WALLET} maxBuys=${MAX_BUYS} maxPay=${ethers.formatEther(MAX_PAY)}BNB`);

  // heartbeat so the log proves it is alive
  setInterval(() => {
    try {
      const cur = parseInt(fs.readFileSync(CURSOR, 'utf8'), 10) || 0;
      log(`[beat] scanned up to block ${cur} · hits=${state.seen.length} · bought=${state.bought}`);
    } catch {}
  }, 60000);

  const isPreset = async (token) => {
    for (const core of CORES) {
      try {
        const r = await p.call({ to: core, data: IFACE.encodeFunctionData('tokens', [token]) });
        const words = r.slice(2).match(/.{64}/g) || [];
        if (words.some((w) => { try { return BigInt('0x' + w) === PRESET_ID; } catch { return false; } })) return core;
      } catch {}
    }
    return null;
  };

  const symbolOf = async (token) => {
    try { return IFACE.decodeFunctionResult('symbol', await p.call({ to: token, data: IFACE.encodeFunctionData('symbol') }))[0]; }
    catch { return ''; }
  };

  const supplyOf = async (token) => {
    try { return IFACE.decodeFunctionResult('totalSupply', await p.call({ to: token, data: IFACE.encodeFunctionData('totalSupply') }))[0]; }
    catch { return 0n; }
  };

  const handleToken = async (token, core, block) => {
    const key = token.toLowerCase();
    if (state.seen.includes(key)) return;
    state.seen.push(key);
    fs.writeFileSync(STATE, JSON.stringify(state, null, 2));

    const sym = await symbolOf(token);
    if (BLACKLIST.includes(key)) { log(`[skip] ${token} symbol=${sym} blacklisted test token`); return; }
    if (/^test/i.test(sym)) { log(`[skip] ${token} symbol=${sym} starts with test`); return; }
    if (state.bought >= MAX_BUYS) { log(`[skip] ${token} symbol=${sym} already bought ${MAX_BUYS}`); return; }

    const supply = await supplyOf(token);
    const amount = (supply * 9n) / 1000n; // 0.9% of maxSupply
    log(`[HIT] ${token} symbol=${sym} block=${block} core=${core} amount=${ethers.formatUnits(amount, 18)} (0.9% supply)`);

    const data = BUY_IFACE.encodeFunctionData('buy', [token, amount, MAX_PAY, 0, '0x']);
    let simOk = false;
    let reason = '';
    try {
      await p.call({ from: WALLET, to: core, data, value: MAX_PAY });
      simOk = true;
    } catch (e) {
      const raw = e?.data || e?.info?.error?.data || '';
      reason = String(raw).slice(0, 10);
    }

    if (!simOk) {
      const mapped = reason === '0x96ea0b74'
        ? 'Agent ID required (Binance Agentic Wallet with Agent ID)'
        : `simulation failed ${reason}`;
      log(`[BLOCKED] ${token} ${sym}: ${mapped} - no tx sent`);
      return;
    }

    log(`[READY] ${token} ${sym}: simulation passed, submitting buy`);
    const preview = parseJson((await runBaw([
      'contract-call', 'preview', '--binanceChainId', '56',
      '--from', WALLET, '--to', core, '--value', String(MAX_PAY),
      '--inputData', data, '--json',
    ])).out);
    if (!preview?.success) {
      log(`[FAIL] ${sym} preview: ${preview?.error?.message || 'unknown'}`);
      return;
    }
    const exec = parseJson((await runBaw(['contract-call', 'execute', '--requestId', preview.data.requestId, '--json'])).out);
    if (exec?.success) {
      log(`[BUY] ${sym} ${exec.data.status} tx=${exec.data.txHash || '-'} ${exec.data.message || ''}`);
      state.bought += 1;
      fs.writeFileSync(STATE, JSON.stringify(state, null, 2));
    } else {
      log(`[FAIL] ${sym} execute: ${exec?.error?.message || 'unknown'}`);
    }
  };

  setInterval(async () => {
    try {
      const head = await p.getBlockNumber();
      for (let n = cursor + 1; n <= head; n++) {
        const block = await p.getBlock(n, true);
        if (!block) continue;
        for (const tx of block.transactions) {
          const to = (tx.to || '').toLowerCase();
          if (!CORES.some((c) => c.toLowerCase() === to)) continue;
          const rc = await p.getTransactionReceipt(tx.hash);
          if (!rc) continue;
          const cands = new Set();
          for (const lg of rc.logs) {
            cands.add(lg.address);
            for (const t of lg.topics.slice(1)) {
              if (t.length === 66) cands.add(ethers.getAddress('0x' + t.slice(26)));
            }
          }
          for (const c of cands) {
            if (c === ethers.ZeroAddress) continue;
            if (CORES.some((x) => x.toLowerCase() === c.toLowerCase())) continue;
            const core = await isPreset(c);
            if (core) await handleToken(c, core, n);
          }
        }
        cursor = n;
      }
      fs.writeFileSync(CURSOR, String(cursor));
    } catch (e) {
      log('poll error: ' + (e.shortMessage || e.message));
    }
  }, 1000);
})();
