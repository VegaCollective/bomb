const { ethers } = require('ethers');

const W1 = '0x2d8061328852b7E4196a482071026cE91edcBa8b';
const HELPER3 = '0xF251F83e40a78868FcfA3FA4599Dad6494E46034';
const FACTORY = '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73';
const WBNB = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';
const USDT = '0x55d398326f99059ff775485246999027b3197955';
const ZERO = '0x0000000000000000000000000000000000000000';

const TOKENS = [
  ['牛币', '0xac0d1e7a790469df1f5cd8ab95c38546a053289b', 46904.96382701293010944, 18],
  ['DAGOU', '0x39b58c3930d4352b2e4d8697ea6188c864455555', 0.000232903894934086, 18],
  ['GSTOCK', '0x4a8fb3757678214aea93e5903732c65ea260caa9', 100471.744726483186214514, 18],
  ['BIBI', '0x24881534007105a6d0728040ffdda1682ff92998', 45984.80414209120141312, 18],
  ['DAWG', '0x846029a144d1756fed43ee0b3f54591bc964ad8b', 44415.090686003377078272, 18],
  ['AGENT', '0xc4605c6a7765138784b3ca6f9a88e1c249a0d21f', 2, 18],
  ['POA', '0xd87adb2e47979d6cb323896b1a9320e0dd132213', 1, 18],
];

const word = (hex, i) => '0x' + hex.slice(2 + i * 64 + 24, 2 + (i + 1) * 64);

(async () => {
  const p = new ethers.JsonRpcProvider('https://bsc-dataseed.binance.org', 56, { staticNetwork: true });
  const helper = new ethers.Interface(['function getTokenInfo(address) view returns (uint256)']);
  const padIface = new ethers.Interface(['function launchpad() view returns (address)']);
  const pairAbi = new ethers.Interface(['function getPair(address,address) view returns (address)']);
  const erc = new ethers.Interface(['function balanceOf(address) view returns (uint256)', 'function approve(address,uint256)']);

  for (const [sym, addr, amt, dec] of TOKENS) {
    let venue = 'none';
    let manager = null;
    try {
      const r = await p.call({ to: HELPER3, data: helper.encodeFunctionData('getTokenInfo', [addr]) });
      let m = ethers.getAddress(word(r, 0));
      if (BigInt(m) < 0x10000n) m = ethers.getAddress(word(r, 1));
      if (m.toLowerCase() !== ZERO) { venue = 'TM2'; manager = m; }
    } catch {}
    if (venue === 'none') {
      try {
        const r = await p.call({ to: addr, data: padIface.encodeFunctionData('launchpad') });
        const pad = ethers.getAddress(word(r, 0));
        if (pad.toLowerCase() !== ZERO) { venue = 'pad'; manager = pad; }
      } catch {}
    }
    let pair = null;
    if (venue === 'none') {
      for (const q of [WBNB, USDT]) {
        try {
          const r = await p.call({ to: FACTORY, data: pairAbi.encodeFunctionData('getPair', [addr, q]) });
          const pa = pairAbi.decodeFunctionResult('getPair', r)[0];
          if (pa !== ethers.ZeroAddress) { pair = pa; break; }
        } catch {}
      }
      if (pair) venue = 'DEX';
    }
    console.log(`${sym.padEnd(8)} ${addr}  venue=${venue}${manager ? ' ' + manager : ''}${pair ? ' pair=' + pair : ''}`);
  }
})().catch(e => console.error('FATAL', e.message));
