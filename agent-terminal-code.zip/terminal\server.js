const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { ethers } = require('ethers');

// ---------- config ----------
const CFG_PATH = path.join(__dirname, 'config.json');
const DEFAULTS = {
  port: 17890,
  proxy: 'http://127.0.0.1:7897',
  rpc: 'https://bsc-dataseed.binance.org',
  cliPath: '',
  fourmeme: '',
  wallets: {
    w1: { label: 'W1', dir: '', id: 'baw-a', addr: '' },
    w2: { label: 'W2', dir: '', id: 'baw-b', addr: '' },
  },
};
let CFG = DEFAULTS;
try { CFG = { ...DEFAULTS, ...JSON.parse(fs.readFileSync(CFG_PATH, 'utf8')) }; } catch {}
const CLI = CFG.cliPath || 'C:\\Users\\Administrator\\baw-multi\\cli\\dist\\index.js';
const FOURMEME = CFG.fourmeme || path.join(process.env.APPDATA || '', 'npm', 'fourmeme.cmd');
const WALLETS = CFG.wallets;

if (CFG.proxy) {
  process.env.HTTP_PROXY = process.env.HTTP_PROXY || CFG.proxy;
  process.env.HTTPS_PROXY = process.env.HTTPS_PROXY || CFG.proxy;
}
process.env.NODE_USE_ENV_PROXY = '1';
process.env.NO_PROXY = process.env.NO_PROXY || '127.0.0.1,localhost';
const BASE_ENV = {
  ...process.env,
  HTTP_PROXY: 'http://127.0.0.1:7897',
  HTTPS_PROXY: 'http://127.0.0.1:7897',
  NO_PROXY: '127.0.0.1,localhost',
  NODE_USE_ENV_PROXY: '1',
};
const BNB = '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE';
const ZERO = '0x0000000000000000000000000000000000000000';
const TM2 = '0x5c952063c7fc8610ffdb798152d69f0b9550762b';
const HELPER3 = '0xF251F83e40a78868FcfA3FA4599Dad6494E46034';
const FLAP_PORTAL = '0xe2ce6ab80874fa9fa2aae65d277dd6b8e65c9de0';
const PADS = {
  '0xf81c4e51c48466c6025b0165b1ea0f6978c712cb': 'Gang LaunchpadU',
  '0x60aee38576035e757ded30ff8db8a8da476430c1': 'Gang LaunchpadS',
};

const provider = new ethers.JsonRpcProvider(CFG.rpc, 56, { staticNetwork: true });
const IFACE = new ethers.Interface([
  'function approve(address,uint256)',
  'function buyTokenAMAP(address,uint256,uint256)',
  'function sellToken(address,uint256)',
  'function getTokenInfo(address) view returns (address tokenManager, uint256 version, address quote, uint256 price, uint256 offers, uint256 funds, bool liquidityAdded)',
  'function launchpad() view returns (address)',
  'function quoteExactInput((address inputToken,address outputToken,uint256 inputAmount)) returns (uint256)',
  'function swapExactInput((address inputToken,address outputToken,uint256 inputAmount,uint256 minOutputAmount,bytes permitData)) payable returns (uint256)',
  'function balanceOf(address) view returns (uint256)',
  'function isAgent(address) view returns (bool)',
  'function tokens(address) view returns (uint256)',
]);

const OPENFOUR_CORES = [
  '0xebe7b6C1089D9F72aD07f34E36d898e44E5e27f3',
  '0x912CEf0C3aE9Ab6eB3Ec87cab69371cFb317Ab94',
];
const AGENT_PRESET_ID = 1778027615735n;

// detect OpenFour "Binance Agent ID Exclusive" preset by scanning core.tokens(token) words
async function detectPreset(token) {
  for (const core of OPENFOUR_CORES) {
    try {
      const r = await provider.call({ to: core, data: IFACE.encodeFunctionData('tokens', [token]) });
      if (!r || r.length < 66) continue;
      const words = r.slice(2).match(/.{64}/g) || [];
      const hit = words.some((w) => {
        try { return BigInt('0x' + w) === AGENT_PRESET_ID; } catch { return false; }
      });
      if (hit) return { core, agentPreset: true };
    } catch {}
  }
  return { core: null, agentPreset: false };
}

const jobs = new Map();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// OpenFour / four.meme custom error selectors
const ERR_MAP = {
  '0x96ea0b74': '该盘仅限「带 Agent ID 的 Binance Agentic Wallet」交易，当前钱包不是 Agent 钱包',
  '0x63d7653c': 'Creator 预售额度超限（raise × 1.5%）',
  '0xe8c402c1': '曲线买入触发 1% 持仓上限（maxSupply × 1%）',
  '0x687d0d11': '交易模块触发 1% 持仓上限',
  '0xa6708f30': '该代币在迁移前禁止 P2P 转账（TransferLocked）',
};

function decodeRevert(data) {
  if (!data || data === '0x') return null;
  const sel = data.slice(0, 10).toLowerCase();
  return ERR_MAP[sel] ? `${ERR_MAP[sel]}（${sel}）` : null;
}

async function explainRevert(to, data, value) {
  try {
    await provider.call({ to, data, value });
    return null;
  } catch (e) {
    const raw = e?.data || e?.info?.error?.data;
    return decodeRevert(raw) || (raw ? `revert data ${String(raw).slice(0, 10)}` : null);
  }
}

function runBaw(wallet, args) {
  return new Promise((resolve) => {
    const w = WALLETS[wallet];
    if (!w) return resolve({ code: -1, out: '', err: 'unknown wallet' });
    const env = { ...BASE_ENV, BINANCE_BAW_DIR: w.dir, BINANCE_INSTANCE_ID: w.id };
    const child = spawn(process.execPath, [CLI, ...args], { env });
    let out = '', err = '';
    child.stdout.on('data', (d) => (out += d));
    child.stderr.on('data', (d) => (err += d));
    child.on('close', (code) => resolve({ code, out, err }));
  });
}

function runFourmeme(args) {
  return new Promise((resolve) => {
    const child = spawn(FOURMEME, args, { shell: true, env: BASE_ENV });
    let out = '', err = '';
    child.stdout.on('data', (d) => (out += d));
    child.stderr.on('data', (d) => (err += d));
    child.on('close', (code) => resolve({ code, out, err }));
  });
}

const parse = (s) => {
  const i = s.indexOf('{');
  if (i < 0) return null;
  try { return JSON.parse(s.slice(i)); } catch { return null; }
};
const fmtEth = (wei) => ethers.formatEther(wei);

function makeJob(kind, wallet) {
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const job = { id, kind, wallet, status: 'running', logs: [], startedAt: new Date().toISOString() };
  jobs.set(id, job);
  return job;
}
const log = (job, msg, level = 'info') => job.logs.push({ t: new Date().toISOString().slice(11, 19), msg, level });

async function getStatus(wallet) {
  const [st, set, bal] = await Promise.all([
    runBaw(wallet, ['wallet', 'status', '--json']),
    runBaw(wallet, ['wallet', 'settings', '--json']),
    runBaw(wallet, ['wallet', 'balance', '--json']),
  ]);
  return {
    wallet,
    addr: WALLETS[wallet]?.addr || '',
    label: WALLETS[wallet]?.label || wallet.toUpperCase(),
    status: parse(st.out)?.data?.status ?? 'UNKNOWN',
    settings: parse(set.out)?.data ?? null,
    balances: parse(bal.out)?.data ?? [],
  };
}

// ---------- platform detection ----------
const word = (hex, i) => '0x' + hex.slice(2 + i * 64 + 24, 2 + (i + 1) * 64);
async function detect(token) {
  try {
    const r = await provider.call({ to: HELPER3, data: IFACE.encodeFunctionData('getTokenInfo', [token]) });
    if (r && r.length >= 66) {
      let manager = ethers.getAddress(word(r, 0));
      // some deployments return (uint256 version, address tokenManager, ...)
      if (BigInt(manager) < 0x10000n && r.length >= 130) manager = ethers.getAddress(word(r, 1));
      if (manager.toLowerCase() !== ZERO) {
        return { kind: 'four', manager };
      }
    }
  } catch {}
  try {
    const r = await provider.call({ to: token, data: IFACE.encodeFunctionData('launchpad') });
    if (r && r.length >= 66) {
      const venue = ethers.getAddress(word(r, 0));
      if (venue.toLowerCase() !== ZERO) {
        if (venue.toLowerCase() === FLAP_PORTAL) return { kind: 'flap', portal: venue };
        if (PADS[venue.toLowerCase()]) return { kind: 'pad', pad: venue, padName: PADS[venue.toLowerCase()] };
        // gang-family pads all expose isAgent(address)
        try {
          const r2 = await provider.call({ to: venue, data: IFACE.encodeFunctionData('isAgent', [Object.values(WALLETS)[0]?.addr || ZERO]) });
          if (r2 && r2.length >= 66) return { kind: 'pad', pad: venue, padName: 'Gang-style pad (isAgent)' };
        } catch {}
        return { kind: 'flap', portal: venue, unknownVenue: true };
      }
    }
  } catch {}
  return { kind: 'dex' };
}

// gang.fun API carries quoteAddress per token
async function gangQuote(token) {
  try {
    const r = await fetch('https://gang.fun/api/stocks/tokens?limit=300');
    const j = await r.json();
    const it = (j.items || []).find((x) => String(x.address).toLowerCase() === token.toLowerCase());
    if (it?.quoteAddress) return { token: it.quoteAddress, getter: 'gang API quoteAddress' };
  } catch {}
  return null;
}

// try to discover the quote token a gang pad uses
async function padQuote(pad) {
  const getters = ['quote()', 'quoteToken()', 'QUOTE()', 'base()', 'baseToken()', 'quoteAsset()'];
  for (const g of getters) {
    try {
      const iface = new ethers.Interface(['function ' + g + ' view returns (address)']);
      const r = await provider.call({ to: pad, data: iface.encodeFunctionData(g.slice(0, g.indexOf('('))) });
      if (r && r.length >= 66) {
        const a = ethers.getAddress(word(r, 0));
        if (a.toLowerCase() !== ZERO) return { getter: g, token: a };
      }
    } catch {}
  }
  return null;
}

// ---------- baw helpers ----------
async function pollOrder(job, wallet, orderId, times = 20) {
  for (let i = 0; i < times; i++) {
    const j = parse((await runBaw(wallet, ['market-order', 'list', '--orderId', String(orderId), '--json'])).out);
    const o = j?.data?.list?.[0];
    if (o) {
      if (o.status === 'FINISHED' || o.status === 'FAILED') {
        log(job, `订单 ${orderId} ${o.status} out=${o.toTokenActualQty} tx=${o.txHash}`, o.status === 'FINISHED' ? 'ok' : 'err');
        return o;
      }
      if (i % 2 === 0) log(job, `订单 ${orderId} ${o.status}…`, 'wait');
    }
    await sleep(3000);
  }
  log(job, `订单 ${orderId} 仍在处理`, 'wait');
  return null;
}

async function marketSwap(job, wallet, fromToken, toToken, qty, label) {
  log(job, `${label}：${qty} → ${toToken.slice(0, 10)}…`);
  const s = parse((await runBaw(wallet, ['market-order', 'swap', '--fromTokenQty', String(qty), '--fromToken', fromToken, '--toToken', toToken, '--binanceChainId', '56', '--json'])).out);
  if (!s?.success) {
    log(job, `${label}失败：${s?.error?.message || 'unknown'}`, 'err');
    return null;
  }
  log(job, `已提交 orderId=${s.data.orderId}`, 'ok');
  return pollOrder(job, wallet, s.data.orderId);
}

async function contractCall(job, wallet, to, valueWei, data, label) {
  log(job, `${label}：preview…`);
  const pv = parse((await runBaw(wallet, ['contract-call', 'preview', '--binanceChainId', '56', '--from', WALLETS[wallet].addr, '--to', to, '--value', String(valueWei), '--inputData', data, '--json'])).out);
  if (!pv?.success) {
    let extra = null;
    try { extra = await explainRevert(to, data, valueWei); } catch {}
    log(job, `preview 失败：${pv?.error?.message || 'unknown'}${extra ? '｜' + extra : ''}`, 'err');
    return null;
  }
  const risks = (pv.data.risks?.riskDetails || []).map((r) => r.title).join('; ');
  log(job, `模拟通过${risks ? '，风险：' + risks : '，无风险标记'}${pv.data.requireConfirmation ? '，需 App 确认' : ''}`, 'ok');
  const ex = parse((await runBaw(wallet, ['contract-call', 'execute', '--requestId', pv.data.requestId, '--json'])).out);
  if (!ex?.success) {
    log(job, `${label} 执行失败：${ex?.error?.message || 'unknown'}`, 'err');
    return null;
  }
  if (ex.data.status === 'BROADCASTED') {
    log(job, `${label} 已广播 tx=${ex.data.txHash}`, 'ok');
  } else {
    log(job, `${label} ${ex.data.status}：${ex.data.message || '请在 App 确认'}`, 'wait');
  }
  return ex.data;
}

// ---------- flows ----------
async function buyFlow(job, wallet, token, amountBnb) {
  const info = await detect(token);
  const preset = await detectPreset(token);
  log(job, `买入 ${amountBnb} BNB → ${token}（${WALLETS[wallet].label}）｜盘口：${info.kind}${preset.agentPreset ? ' · Agent ID 专属盘' : ''}`);
  if (preset.agentPreset) {
    log(job, '该盘为 Binance Agent ID Exclusive，交易需钱包持有 Agent ID；无 ID 会在链上被拒（0x96ea0b74）', 'wait');
  }

  if (info.kind === 'dex') {
    const q = parse((await runBaw(wallet, ['market-order', 'quote', '--fromTokenQty', String(amountBnb), '--fromToken', BNB, '--toToken', token, '--binanceChainId', '56', '--json'])).out);
    if (!q?.success) {
      log(job, `报价失败：${q?.error?.message || 'no route'}`, 'err');
      job.status = 'failed';
      return;
    }
    log(job, `报价 ${q.data.fromCoinAmount} ${q.data.fromCoinSymbol} → ${q.data.toCoinAmount} ${q.data.toCoinSymbol}`, 'ok');
    const s = parse((await runBaw(wallet, ['market-order', 'swap', '--fromTokenQty', String(amountBnb), '--fromToken', BNB, '--toToken', token, '--binanceChainId', '56', '--json'])).out);
    if (!s?.success) {
      log(job, `下单失败：${s?.error?.message || 'unknown'}`, 'err');
      job.status = 'failed';
      return;
    }
    log(job, `已提交 orderId=${s.data.orderId}`, 'ok');
    const o = await pollOrder(job, wallet, s.data.orderId);
    job.status = o?.status === 'FINISHED' ? 'done' : 'failed';
    return;
  }

  if (info.kind === 'four') {
    log(job, `内盘底池 TokenManager2（${info.manager.slice(0, 10)}…）`, 'ok');
    const fundsWei = ethers.parseEther(String(amountBnb));
    const q = parse((await runFourmeme(['quote-buy', token, '0', String(fundsWei)])).out);
    if (!q) {
      log(job, '报价失败（fourmeme quote 无返回）', 'err');
      job.status = 'failed';
      return;
    }
    const quote = String(q.quote);
    const isNative = quote === 'native' || quote.toLowerCase() === ZERO;
    let spend = fundsWei;
    let quoteToken = null;

    if (!isNative) {
      quoteToken = quote;
      log(job, `计价币非 BNB（${quoteToken}），自动换汇 ${amountBnb} BNB…`);
      const o = await marketSwap(job, wallet, BNB, quoteToken, amountBnb, '换汇');
      if (!o || o.status !== 'FINISHED') { job.status = 'failed'; return; }
      spend = ethers.parseEther(String(o.toTokenActualQty));
      log(job, `换得 ${fmtEth(spend)} 计价币`, 'ok');
      const ap = await contractCall(job, wallet, quoteToken, 0, IFACE.encodeFunctionData('approve', [TM2, spend]), '授权');
      if (!ap) { job.status = 'failed'; return; }
      await sleep(4000);
    }

    const minOut = (BigInt(q.estimatedAmount) * 95n) / 100n;
    const data = IFACE.encodeFunctionData('buyTokenAMAP', [token, spend, minOut]);
    const res = await contractCall(job, wallet, TM2, isNative ? spend : 0n, data, '内盘买入');
    job.status = res ? 'done' : 'failed';
    return;
  }

  if (info.kind === 'pad') {
    log(job, `${info.padName}（${info.pad.slice(0, 10)}…）`, 'ok');
    const q = (await padQuote(info.pad)) || (await gangQuote(token));
    if (!q) {
      log(job, `无法确定该盘的计价币（已尝试 quote()/quoteToken()/base() 等），暂不支持自动买入`, 'err');
      job.status = 'failed';
      return;
    }
    log(job, `计价币 ${q.token}（来自 ${q.getter}）`, 'ok');
    const fundsWei = ethers.parseEther(String(amountBnb));
    let spend = fundsWei;
    if (q.token.toLowerCase() !== BNB) {
      const o = await marketSwap(job, wallet, BNB, q.token, amountBnb, '换汇');
      if (!o || o.status !== 'FINISHED') { job.status = 'failed'; return; }
      spend = ethers.parseEther(String(o.toTokenActualQty));
      log(job, `换得 ${fmtEth(spend)} 计价币`, 'ok');
      const ap = await contractCall(job, wallet, q.token, 0, IFACE.encodeFunctionData('approve', [info.pad, spend]), '授权');
      if (!ap) { job.status = 'failed'; return; }
      await sleep(4000);
    }
    const iface = new ethers.Interface(['function buy(address,uint256,uint256)']);
    const data = iface.encodeFunctionData('buy', [token, spend, 0]);
    const res = await contractCall(job, wallet, info.pad, q.token.toLowerCase() === BNB ? spend : 0n, data, 'Pad 买入');
    job.status = res ? 'done' : 'failed';
    return;
  }

  if (info.kind === 'flap') {
    if (info.unknownVenue) {
      log(job, `合约返回的交易场所 ${info.portal} 不在已知识别表内，无法报价`, 'err');
      job.status = 'failed';
      return;
    }
    log(job, `Flap Portal ${info.portal.slice(0, 10)}…，走 swapExactInput`, 'ok');
    const amount = ethers.parseEther(String(amountBnb));
    const qd = IFACE.encodeFunctionData('quoteExactInput', [[ethers.ZeroAddress, token, amount]]);
    let out = 0n;
    try {
      out = BigInt(await provider.call({ to: info.portal, data: qd }));
      if (out === 0n) {
        log(job, '报价为 0：该币曲线可能尚未开启', 'err');
        job.status = 'failed';
        return;
      }
      log(job, `报价：${amountBnb} BNB → ${ethers.formatUnits(out, 18)} 代币`, 'ok');
    } catch (e) {
      log(job, '报价 revert：Portal 上没有这枚币的有效曲线（可能未开盘或已迁移 DEX）', 'err');
      job.status = 'failed';
      return;
    }
    const minOut = (out * 99n) / 100n;
    const data = IFACE.encodeFunctionData('swapExactInput', [[ethers.ZeroAddress, token, amount, minOut, '0x']]);
    const res = await contractCall(job, wallet, info.portal, amount, data, 'Flap 买入');
    job.status = res ? 'done' : 'failed';
    return;
  }

  job.status = 'failed';
}

async function sellFlow(job, wallet, token, percent) {
  const info = await detect(token);
  log(job, `卖出 ${percent}% ${token}（${WALLETS[wallet].label}）｜盘口：${info.kind}`);

  const balRaw = await provider.call({ to: token, data: IFACE.encodeFunctionData('balanceOf', [WALLETS[wallet].addr]) });
  const bal = IFACE.decodeFunctionResult('balanceOf', balRaw)[0];
  if (bal === 0n) {
    log(job, '持仓为 0', 'err');
    job.status = 'failed';
    return;
  }
  const qty = (bal * BigInt(Math.round(percent * 100))) / 10000n;
  log(job, `持仓 ${ethers.formatUnits(bal, 18)}，卖出 ${ethers.formatUnits(qty, 18)}`, 'ok');

  if (info.kind === 'four') {
    const ap = await contractCall(job, wallet, token, 0, IFACE.encodeFunctionData('approve', [TM2, qty]), '授权');
    if (!ap) { job.status = 'failed'; return; }
    await sleep(4000);
    const data = IFACE.encodeFunctionData('sellToken', [token, qty]);
    const res = await contractCall(job, wallet, TM2, 0, data, '内盘卖出');
    job.status = res ? 'done' : 'failed';
    return;
  }

  if (info.kind === 'pad') {
    log(job, `${info.padName} 卖出`, 'ok');
    const ap = await contractCall(job, wallet, token, 0, IFACE.encodeFunctionData('approve', [info.pad, qty]), '授权');
    if (!ap) { job.status = 'failed'; return; }
    await sleep(4000);
    const padIface = new ethers.Interface(['function sell(address,uint256,uint256)']);
    const res = await contractCall(job, wallet, info.pad, 0, padIface.encodeFunctionData('sell', [token, qty, 0]), 'Pad 卖出');
    job.status = res ? 'done' : 'failed';
    return;
  }

  const o = await marketSwap(job, wallet, token, BNB, ethers.formatUnits(qty, 18), '卖出');
  job.status = o?.status === 'FINISHED' ? 'done' : 'failed';
}

// ---------- http ----------
// ---------- BNB price from Pancake V2 (no external API needed) ----------
const PANCAKE_ROUTER = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
const WBNB = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';
const USDT = '0x55d398326f99059fF775485246999027B3197955';
const priceCache = { value: null, at: 0 };
async function bnbPrice() {
  const now = Date.now();
  if (priceCache.at && now - priceCache.at < 60000) return { bnbUsd: priceCache.value, at: priceCache.at };
  const word = (v) => BigInt(v).toString(16).padStart(64, '0');
  const addrWord = (a) => a.toLowerCase().replace(/^0x/, '').padStart(64, '0');
  const data = '0xd06ca61f' + word(10n ** 18n) + word(0x40) + word(2n) + addrWord(WBNB) + addrWord(USDT);
  const r = await provider.call({ to: PANCAKE_ROUTER, data });
  const words = r.slice(2).match(/.{64}/g) || [];
  const last = words[words.length - 1];
  priceCache.value = Number(BigInt('0x' + last)) / 1e18;
  priceCache.at = now;
  return { bnbUsd: priceCache.value, at: priceCache.at };
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://127.0.0.1');
  const send = (code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(obj)); };

  if (url.pathname === '/' || url.pathname === '/index.html') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html')));
  }

  if (url.pathname === '/api/status') {
    try { return send(200, await getStatus(url.searchParams.get('w') || 'w1')); }
    catch (e) { return send(500, { error: e.message }); }
  }

  if (url.pathname === '/api/buy' && req.method === 'POST') {
    const b = safeJson(await readBody(req));
    if (!b?.wallet || !b?.token) return send(400, { error: 'bad body' });
    const job = makeJob('buy', b.wallet);
    buyFlow(job, b.wallet, b.token, b.amount).catch((e) => { log(job, e.message, 'err'); job.status = 'failed'; });
    return send(200, { jobId: job.id });
  }

  if (url.pathname === '/api/sell' && req.method === 'POST') {
    const b = safeJson(await readBody(req));
    if (!b?.wallet || !b?.token) return send(400, { error: 'bad body' });
    const job = makeJob('sell', b.wallet);
    sellFlow(job, b.wallet, b.token, b.percent).catch((e) => { log(job, e.message, 'err'); job.status = 'failed'; });
    return send(200, { jobId: job.id });
  }

  if (url.pathname === '/api/detect') {
    const token = url.searchParams.get('token') || '';
    if (!/^0x[0-9a-fA-F]{40}$/.test(token)) return send(400, { error: 'bad token' });
    try {
      const det = await detect(token);
      const preset = await detectPreset(token);
      return send(200, { ...det, ...preset });
    } catch (e) { return send(500, { error: e.message }); }
  }

  if (url.pathname === '/api/price') {
    try {
      const price = await bnbPrice();
      return send(200, price);
    } catch (e) { return send(200, { bnbUsd: null, error: e.message }); }
  }

  if (url.pathname === '/api/jobs') {
    const list = [...jobs.values()].slice(-20).map((j) => ({
      id: j.id, kind: j.kind, wallet: j.wallet, status: j.status, startedAt: j.startedAt, last: j.logs[j.logs.length - 1],
    }));
    return send(200, { jobs: list });
  }

  if (url.pathname === '/api/job') {
    const job = jobs.get(url.searchParams.get('id'));
    return job ? send(200, job) : send(404, { error: 'no job' });
  }

  send(404, { error: 'not found' });
});

function readBody(req) {
  return new Promise((resolve) => {
    let d = '';
    req.on('data', (c) => (d += c));
    req.on('end', () => resolve(d || '{}'));
  });
}
function safeJson(s) { try { return JSON.parse(s); } catch { return null; } }

process.on('unhandledRejection', (e) => console.error('unhandled', e));
process.on('uncaughtException', (e) => console.error('uncaught', e));

server.listen(CFG.port, '127.0.0.1', () => console.log(`terminal on http://127.0.0.1:${CFG.port}`));
