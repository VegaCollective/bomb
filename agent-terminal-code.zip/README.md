# Binance Agentic Wallet · 交易终端与狙击脚本

本机运行的 BSC 交易工具集：一个网页终端 + 三个后台监控脚本。
签名全部在 Binance App 内完成，仓库内**不含私钥、会话、钱包地址或任何密钥**。

## 目录

```
terminal/            网页交易终端（Node + 原生 HTML）
  server.js          服务端：钱包状态、盘口识别、买卖、价格接口
  public/index.html  界面
watch/               后台脚本
  sniper-pool.js     按计价币分池狙击（每池前 3，全局名额）
  tp.js              止盈：毕业 + 翻倍后卖 10%
  sniper.js          链上事件备用扫描
  hidden-holdings.js 找出被 CLI 隐藏的小额持仓
  sellability.js     判断持仓能否卖出（DEX / 内盘 / 不可卖）
  value-hidden.js    给隐藏持仓估值
notes/               研究笔记（OpenFour Agent ID 机制）
```

## 运行前提

1. Node.js 20+
2. `npm i -g @binance/agentic-wallet`
3. Binance App → Agentic Wallet → 打开 Developer Mode
4. 本机代理（默认 `127.0.0.1:7897`，按需改脚本里的地址）

## 启动

```bash
# 终端
cd terminal && npm install && node server.js
# 打开 http://127.0.0.1:17890

# 狙击（示例：只盯 BNCB 计价的新池）
cd watch
SNIPE_QUOTE=0x4902c5ebc598265ed2212b559b042de8a5eeec3f node sniper-pool.js

# 止盈
node tp.js
```

## 配置

脚本顶部的 `WALLET` / `BAW_ENV` / `CLI` 需要改成你自己的：

- `CLI`：`baw` 的 `dist/index.js` 路径
- `BAW_ENV.BINANCE_BAW_DIR`：会话目录
- `BAW_ENV.BINANCE_INSTANCE_ID`：实例 ID
- `WALLET`：你的钱包地址

## 两个可调环境变量

| 变量 | 默认 | 说明 |
|---|---|---|
| `SNIPE_QUOTE` | 空（全部） | 只狙击指定计价币的池，填合约地址 |
| `SNIPER_MAX_PAY` | 0.2 | 单笔 BNB 上限 |
| `SNIPE_PER_POOL` | 3 | 每池名额 |
| `SNIPE_GLOBAL_MAX` | 5 | 全局名额 |
| `PLAN_ONLY` | 空 | 设为 1 则只演练不下单 |

## 注意

- 默认是**实盘**，启动即会按规则下单，请先确认参数。
- 本仓库不含任何钱包凭据；每个人需要用自己的币安钱包登录。
- 部分交易会触发币安风控，需要在 App 二次确认。
