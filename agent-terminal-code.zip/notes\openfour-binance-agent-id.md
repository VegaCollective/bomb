# OpenFour · Binance Agent ID Exclusive（学习笔记）

来源：[binance-agent-id-exclusive.md](https://github.com/four-meme-community/openfour-docs/blob/main/docs/zh-Hant/mechanisms/binance-agent-id-exclusive.md)
整理时间：2026-10-24

---

## 1. 这是什么

OpenFour 的一个 bonding preset，面向**持有 Agent ID 的 Binance Agentic Wallet**。
代币是 `BinanceAgentTaxToken`，继承 `TaxToken`（税费、dispatch、founder 发放、holder 领取机制与 TaxToken 相同），额外加了三个限制：**Agent 门禁、内盘转账锁、持仓上限**。

```
presetId = 1778027615735
```

## 2. 谁能参与

| 动作 | 条件 |
|---|---|
| 创建代币 | **任意 EOA**，不需要 Agent ID |
| Creator 首块预售 | creator 本人，不需要 Agent ID；上限 `raise × 1.5%` |
| 其他买入 | **必须 Binance Agentic Wallet with Agent ID** |
| 卖出 | creator 本人，或带 Agent ID 的钱包 |

前置：币安 App → Agentic Wallet → 打开 Developer Mode。

## 3. 量化规则

| 规则 | 数值 |
|---|---|
| 单个地址持仓上限 | `maxSupply × 1%`（creator 首块豁免） |
| Creator 预售上限 | `curveQuote ≤ raiseAmount × 150 / 10000`（1.5%） |
| 税费率范围 | `0–1000 bps`（0–10%） |
| dispatch 阈值 | `minDispatch = 50,000 tokens`；`minDispatchQuote = 0.01 quote` |
| holder 领取门槛 | `minShare` 最低 10,000 tokens（创建者设定） |

买入超上限的处理：曲线会把买入量截到剩余额度，多付的部分**退款**；余额已达上限再买则直接 revert。

## 4. 转账限制

phase 为 `Created / Trading / SoldOut` 时，`_transfer` 只允许两条路径：

| 路径 | from | to | msg.sender |
|---|---|---|---|
| 内盘买入 | vault | 用户 | vault |
| 内盘卖出 | 用户 | vault | Core |

其余任何转账（包括钱包间互转）→ `BinanceAgentTokenErrTransferLocked`。
迁移（Migrated）之后恢复正常 TaxToken 转账规则。

## 5. 如何识别这个 preset

三种方式，任一即可：

1. `TokenCreated.presetId == 1778027615735`
2. `encodedTags` 同时包含
   - `token.tax.binance_agent`
   - `module.curve.bonding_binance_agent`
   - `module.trade.tax_bonding_binance_agent`
3. `token.descriptor().tag == "token.tax.binance_agent"`

**不要**误判成普通 `token.tax` / `module.trade.tax_bonding`。

模块注册表 key：

| 槽位 | Key |
|---|---|
| Token | `TOKEN_BINANCE_AGENT` → `module.token.binance_agent` |
| Curve | `CURVE_BONDING_BINANCE_AGENT` → `module.curve.bonding_binance_agent` |
| Trade | `TRADE_TAX_BONDING_BINANCE_AGENT` → `module.trade.tax_bonding_binance_agent` |
| Token impl | `TOKEN_IMPL_BINANCE_AGENT_TAX` → `token.tax.binance_agent` |

## 6. 错误码（用于解码 revert）

| 错误 | Selector | 含义 |
|---|---|---|
| `BinanceAgentTradeErrOnlyAgenticWallet()` | `0x96ea0b74` | 不是带 Agent ID 的 Agentic Wallet |
| `BinanceAgentTradeErrPresaleCap()` | `0x63d7653c` | Creator 预售超过 raise × 1.5% |
| `BinanceAgentCurveErrHoldCap()` | `0xe8c402c1` | 曲线路径触发 1% 持仓上限 |
| `BinanceAgentTradeErrHoldCap()` | `0x687d0d11` | Trade 模块触发 1% 持仓上限 |
| `BinanceAgentTokenErrTransferLocked()` | `0xa6708f30` | 迁移前禁止 P2P 转账 |

## 7. 税费细节（与普通 TaxToken 的差异）

- 费率下限允许 **0 bps**（普通 Tax preset 通常有下限）
- 上限 **1000 bps（10%）**
- 迁移前转账锁定，但不改变「成交时按 quote 收税」的方式
- `founder` 在 dispatch 时发放，不是走 `claimFee`
- holder 奖励由 Four.meme Keeper 批量发放，通常不需要自己领取
- 可查：`claimableFee(account)` / `claimedFee(account)` / `claimFee()`
- 手动注资：`manualFundHolderRewards` / `supportsManualRewards()` / `totalManualRewards()`

## 8. 落地要点

1. **交易前先判 preset**，否则会拿普通盘的逻辑去打 Agent 盘，白烧 gas。
2. **买入前算持仓上限**：`holdCap - balanceOf(trader)`，接近上限时别一次买满。
3. **买入用 `buyByBudget` 时注意**：预算路径同样受上限约束。
4. **不要用 P2P 转账分发**代币（迁移前会 revert）。
5. **UI 上要暴露税费**：`buyFeeRate` / `sellFeeRate` > 0 时提示，并展示 `claimableFee`。

## 9. 对我们的影响

- W1 / W2 是 Binance Agentic Wallet，但 **EIP-8004 余额 = 0**、`isAgent = false`。
- 因此这个 preset 的币**现在买不了**，会被 `0x96ea0b74` 拒绝。
- 解决路径只有两条：币安 App 里领取 Agent ID，或用 `fourmeme 8004-register` 链上注册（需本地私钥）。
- 终端已接入错误解码，遇到该错误会直接提示「仅限带 Agent ID 的钱包」，不再展示原始 revert。
