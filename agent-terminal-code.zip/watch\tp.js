const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// take-profit watcher: when a sniped position is +100%, sell 10% of it
const OUT_DIR = 'D:\\Backup\\Documents\\deepseek-harness\\default-workspace\\watch';
const POS = path.join(OUT_DIR, 'positions.json');
const LOG = path.join(OUT_DIR, 'tp.log');
const WALLET = '0x2d8061328852b7E4196a482071026cE91edcBa8b';
const TM2 = '0x5c952063c7fc8610ffdb798152d69f0b9550762b';
const CLI = 'C:\\Users\\Administrator\\baw-multi\\cli\\dist\\index.js';
const BAW_ENV = {
  ...process.env,
  HTTP_PROXY: 'http://127.0.0.1:7897',
  HTTPS_PROXY: 'http://127.0.0.1:7897',
  NO_PROXY: '127.0.0.1,localhost',
  NODE_USE_ENV_PROXY: '1',
  BINANCE_BAW_DIR: 'C:\\Users\\Administrator\\baw-multi\\a',
  BINANCE_INSTANCE_ID: 'baw-a',
};
const FOURMEME = path.join(process.env.APPDATA, 'npm', 'fourmeme.cmd');
const TP_RATIO = 2; // +100%
const SELL_FRACTION = 0.1; // 10%
const FACTORY = '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73'; // Pancake V2
const WBNB = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';
const USDT = '0x55d398326f99059Ff775485246999027B3197955';

fs.mkdirSync(OUT_DIR, { recursive: true });
const log = (m) => {
  const line = `[${new Date().toISOString()}] ${m}`;
  console.log(line);
  fs.appendFileSync(LOG, line + '\n');
};

const runBaw = (args) => new Promise((resolve) => {
  const c = spawn(process.execPath, [CLI, ...args], { env: BAW_ENV });
  let out = '', err = '';
  c.stdout.on('data', (d) => (out += d));
  c.stderr.on('data', (d) => (err += d));
  c.on('close', (code) => resolve({ code, out, err }));
});
const runFour = (args) => new Promise((resolve) => {
  const c = spawn(FOURMEME, args, { shell: true, env: BAW_ENV });
  let out = '';
  c.stdout.on('data', (d) => (out += d));
  c.on('close', () => resolve(out));
});
const pj = (s) => { const i = s.indexOf('{'); if (i < 0) return null; try { return JSON.parse(s.slice(i)); } catch { return null; } };

(async () => {
  const p = new ethers.JsonRpcProvider('https://bsc-dataseed.binance.org', 56, { staticNetwork: true });
  const erc = new ethers.Interface([
    'function balanceOf(address) view returns (uint256)',
    'function approve(address,uint256)',
  ]);
  log(`tp watcher armed: wait for graduation, then +${(TP_RATIO - 1) * 100}% → sell ${SELL_FRACTION * 100}%`);

  const pairAbi = new ethers.Interface(['function getPair(address,address) view returns (address)']);
  const isGraduated = async (token) => {
    for (const q of [WBNB, USDT]) {
      try {
        const r = await p.call({ to: FACTORY, data: pairAbi.encodeFunctionData('getPair', [token, q]) });
        const pair = pairAbi.decodeFunctionResult('getPair', r)[0];
        if (pair && pair !== ethers.ZeroAddress) return pair;
      } catch {}
    }
    return null;
  };

  const load = () => {
    try { return JSON.parse(fs.readFileSync(POS, 'utf8')); } catch { return []; }
  };
  const save = (list) => fs.writeFileSync(POS, JSON.stringify(list, null, 2));

  setInterval(async () => {
    const list = load();
    if (!list.length) return;
    for (const pos of list) {
      if (pos.tpDone) continue;
      try {
        // only after the bonding curve graduates to DEX
        const pair = await isGraduated(pos.token);
        if (!pair) {
          if (!pos.waitLogged) { log(`[wait] ${pos.symbol} 曲线未毕业，等待上外盘`); pos.waitLogged = true; save(list); }
          continue;
        }
        if (!pos.gradLogged) { log(`[grad] ${pos.symbol} 已上外盘 pair=${pair}`); pos.gradLogged = true; save(list); }

        // current amount held
        const bal = erc.decodeFunctionResult('balanceOf', await p.call({ to: pos.token, data: erc.encodeFunctionData('balanceOf', [WALLET]) }))[0];
        if (bal === 0n) { pos.tpDone = true; save(list); continue; }

        const slice = (bal * BigInt(Math.round(SELL_FRACTION * 1000))) / 1000n;
        // proceeds of that slice
        const out = await runFour(['quote-sell', pos.token, slice.toString()]);
        const q = pj(out);
        if (!q?.funds || q.funds === '0') continue;
        const proceeds = BigInt(q.funds);
        const costSlice = (BigInt(pos.costWei) * BigInt(Math.round(SELL_FRACTION * 1000))) / 1000n;
        if (costSlice === 0n) continue;
        const ratio = Number(proceeds) / Number(costSlice);
        log(`[check] ${pos.symbol} slice=${ethers.formatUnits(slice, 18)} proceeds=${ethers.formatEther(proceeds)} cost=${ethers.formatEther(costSlice)} x${ratio.toFixed(2)}`);
        if (ratio < TP_RATIO) continue;

        log(`[TP] ${pos.symbol} +${((ratio - 1) * 100).toFixed(0)}% 触发，卖出 ${SELL_FRACTION * 100}%`);
        const ap = pj((await runBaw(['contract-call', 'preview', '--binanceChainId', '56', '--from', WALLET, '--to', pos.token, '--value', '0',
          '--inputData', erc.encodeFunctionData('approve', [TM2, slice.toString()]), '--json'])).out);
        if (ap?.success) await runBaw(['contract-call', 'execute', '--requestId', ap.data.requestId, '--json']);
        await new Promise((r) => setTimeout(r, 6000));

        const sellIface = new ethers.Interface(['function sellToken(address,uint256)']);
        const sp = pj((await runBaw(['contract-call', 'preview', '--binanceChainId', '56', '--from', WALLET, '--to', TM2, '--value', '0',
          '--inputData', sellIface.encodeFunctionData('sellToken', [pos.token, slice.toString()]), '--json'])).out);
        if (sp?.success) {
          const ex = pj((await runBaw(['contract-call', 'execute', '--requestId', sp.data.requestId, '--json'])).out);
          if (ex?.success) {
            log(`[SOLD] ${pos.symbol} ${ex.data.status} tx=${ex.data.txHash || '-'} ${ex.data.message || ''}`);
            pos.tpDone = true;
            save(list);
          }
        }
      } catch (e) {
        log(`[err] ${pos.symbol || pos.token}: ${e.message}`);
      }
    }
  }, 10000);
})();
